import 'package:flutter/material.dart';

Widget starText() {
  return Padding(
    padding: const EdgeInsets.only(top: 8.0),
    child: Text(
      '*',
      // style: primaryTextStyle(color: Colors.red.shade300),
    ),
  );
}
